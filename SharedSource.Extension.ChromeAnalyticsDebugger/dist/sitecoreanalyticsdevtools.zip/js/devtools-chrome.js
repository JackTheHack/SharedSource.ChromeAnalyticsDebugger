var panels = chrome.devtools.panels;

// Grunt panel
var gruntPanel = panels.create(
  "Sitecore",
  "img/icon.png",
  "sitecore_index.html"
);